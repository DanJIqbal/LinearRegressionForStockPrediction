# Regression-Stock-Prediction
Predicting Google’s stock price using various regression techniques. Toy example for learning how to combine numpy, scikit-learn and matplotlib. Work to do.

Based on [this](http://beancoder.com/linear-regression-stock-prediction/) tutorial.
